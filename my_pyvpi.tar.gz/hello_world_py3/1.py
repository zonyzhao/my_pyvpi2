import pyvpi

pyvpi.printf("hello this is python")
