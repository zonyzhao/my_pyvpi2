import pyvpi
import pyvpi_cons as cons
import sys
import os

if __name__ == '__main__':
    print("This is python: hello world")
    print('test passed')
    #IPython.embed()
